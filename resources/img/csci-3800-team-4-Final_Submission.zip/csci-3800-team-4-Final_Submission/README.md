# csci-3800-team-4
our final project repository

Brief Application description
Contributors - Max Pricher, Jacob Hansen, Aubrey Leavenworth, Giovanni Palazzolo
Technology Stack used for the project
End Users: Browser/Web Client
Back End: NodeJS
Front End: HandleBars
Database: PostgreSQL
External: Docker

Prerequisites to run the application
-Docker Desktop
-Any browser

Instructions on how to run the application locally.
-Download the repository
-Navigate to /ProjectSourceCode
-Create a `.env` file in `ProjectSourceCode` using `.env.example`
-Set `OPENAI_API_KEY` in that `.env` file if you want the homepage and notes-page AI summaries enabled
-Docker compose up
-Visit localhost:3000

How to run the tests: Tests will auto run when running the web service.  Run npm test in your terminal if not.

Link to the deployed application: https://csci-3800-team-4-0k2u.onrender.com
